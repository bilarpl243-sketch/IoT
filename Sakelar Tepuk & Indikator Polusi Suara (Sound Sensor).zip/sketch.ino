#define SOUND_DO_PIN 14
#define SOUND_AO_PIN 34
#define RELAY_LED_PIN 12
bool lightState = false;
int lastSoundState = LOW;
void setup() {
Serial.begin(115200);
pinMode(SOUND_DO_PIN, INPUT);
pinMode(RELAY_LED_PIN, OUTPUT);
digitalWrite(RELAY_LED_PIN, lightState);
Serial.println("Sistem Clap Switch / Sound Detector Aktif.");
}
void loop() {
int soundDigital = digitalRead(SOUND_DO_PIN);
int soundAnalog = analogRead(SOUND_AO_PIN);
if (soundDigital == HIGH && lastSoundState == LOW) {
lightState = !lightState; // Toggle status
digitalWrite(RELAY_LED_PIN, lightState ? HIGH : LOW);
Serial.print("-> Suara Terdeteksi! Nilai Analog Peak: ");
Serial.print(soundAnalog);
Serial.print(" | Status Lampu Baru: ");
Serial.println(lightState ? "ON" : "OFF");
delay(300); // Debounce delay
}
lastSoundState = soundDigital;
}
