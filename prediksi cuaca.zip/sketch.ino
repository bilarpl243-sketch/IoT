{
  "version": 1,
  "author": "IoT Course",
  "editor": "wokwi",
  "parts": [
    { "type": "board-esp32-devkit-c-v4", "id": "esp", "top": 0, "left": 0 },
    { "type": "wokwi-dht22", "id": "dht", "top": -120, "left": -100 },
    { "type": "wokwi-lcd1602", "id": "lcd", "top": 150, "left": -50 }
  ],
  "connections": [
    [ "esp:GND.1", "dht:GND", "black", [ "v0" ] ],
    [ "esp:3V3", "dht:VCC", "red", [ "v0" ] ],
    [ "esp:15", "dht:SDA", "green", [ "v0" ] ],
    [ "esp:GND.2", "lcd:GND", "black", [ "v0" ] ],
    [ "esp:5V", "lcd:VCC", "red", [ "v0" ] ],
    [ "esp:21", "lcd:SDA", "blue", [ "v0" ] ],
    [ "esp:22", "lcd:SCL", "yellow", [ "v0" ] ]
  ]
}